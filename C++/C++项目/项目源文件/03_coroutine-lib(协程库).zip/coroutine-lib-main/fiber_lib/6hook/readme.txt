编译
g++ -std=c++17 *.cpp -o test